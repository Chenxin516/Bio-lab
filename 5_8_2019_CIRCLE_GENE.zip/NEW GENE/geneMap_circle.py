# File:             geneMatch_original.py
# Author:           Akaash Venkat, Audi Liu

from selenium import webdriver
from os.path import expanduser
import glob
import math
import random
import os
import subprocess
import sys
import time

GENE_DATABASE_FILE = "info_files/gene_database.txt"
GENE_GROUP_FILE = "info_files/gene_group.txt"
UNIDENTIFIABLE_GENE_FILE = "info_files/unidentifiable_genes.txt"
CHANGED_NAME_GENE_FILE = "info_files/changed_name_genes.txt"

GENE_LIST = [] 
UNIDENTIFIABLE_LIST = []
CHANGED_NAME = {}
GROUP = {}
B_D_PAIR = {}



group1 = ["RPE65", "LRAT", "MERTK", "RBP3", "RGR"] #read-only
group2 = ["RHO", "PRPH2", "SAG", "CNGA1", "CNGB1", "FSCN2", "ROM1", "IMPG2", "PROM1"]
group3 = [ "RPGR", "RP1", "CLRN1", "MAK", "USH2A"] #removed BBSs because not in a_list
group4 = ["NR2E3", "CRX", "ZNF513", "PRPF31", "PRPF8", "PRPF3", "PRPF4", "PRPF6", "RP9", "SNRNP200", "DHX38"]


'''
GROUP1 =[]
GROUP2 = []
GROUP3 = []
GROUP4 = []
'''


        
        
    
def readDatabase():
    with open(GENE_DATABASE_FILE) as database_file:
        for line_content in database_file:
            if line_content != "\n":
                gene_info = []
                line_content = line_content.replace(" ", "")
                line_content = line_content.replace(")", "")
                line_content = line_content.replace("\n", "")
                temp_list = line_content.split("-",1)
                main_gene = temp_list[0]
                connecting_genes_list = temp_list[1].split(",")
                neighbors = {}
                for connecting_gene in connecting_genes_list:
                    name = connecting_gene.split("(")[0] 
                    num = float(connecting_gene.split("(")[1])
                    neighbors[name] = num
                gene_info.append(main_gene)
                gene_info.append(neighbors)
                GENE_LIST.append(gene_info)
    database_file.close()


def readUnidentifiable():
    with open(UNIDENTIFIABLE_GENE_FILE) as unidentifiable_file:
        for line_content in unidentifiable_file:
            line_content = line_content.replace(" ", "")
            line_content = line_content.replace("\n", "")
            if line_content != "" and "followinggenescannotbefound" not in line_content:
                UNIDENTIFIABLE_LIST.append(line_content)
    unidentifiable_file.close()


def readChangedName():
    with open(CHANGED_NAME_GENE_FILE) as changed_name_file:
        for line_content in changed_name_file:
            line_content = line_content.replace(" ", "")
            line_content = line_content.replace("\n", "")
            if line_content != "" and "followinggeneshavebeenrenamed" not in line_content:
                orig_name = line_content.split("=>")[0]
                new_name = line_content.split("=>")[1]
                CHANGED_NAME[orig_name] = new_name
    changed_name_file.close()


def writeToDatabase():
    os.system('rm ' + GENE_DATABASE_FILE)
    os.system('touch ' + GENE_DATABASE_FILE)
    database_file = open(GENE_DATABASE_FILE, "w")
    for counter in range(0, len(GENE_LIST)):
        gene_info = GENE_LIST[counter]
        main_gene = gene_info[0]
        connecting_genes_list = gene_info[1]
        line_content = main_gene + " - "
        for key, value in sorted(connecting_genes_list.items() ):
            line_content = line_content + key + "(" + str(value) + "), " 
        line_content = line_content[:-2]
        database_file.write(line_content + "\n\n")
    database_file.close()


def writeGeneGroups():
    os.system('touch ' + GENE_GROUP_FILE)
    grouping_file = open(GENE_GROUP_FILE, "w")

    groups = ["A", "B", "C", "D"]
    descriptions = ["Input gene that has direct connection with another input gene", "Input gene that is indirectly connected to another input gene, via an intermediate gene", "Input gene that is not directly or indirectly connected to another input gene", "Intermediate gene that connects Group B genes with Group A or other Group B genes"]

    for counter in range(0, len(groups)):
        group_id = groups[counter]
        description = descriptions[counter]
        grouping_file.write("Group " + group_id + ": " + description + "\n")
        grouping_file.write("---\n")
        cluster = getListForGroup(group_id)
        for gene in cluster:
            grouping_file.write(gene + "\n")
        grouping_file.write("\n\n\n")

    grouping_file.close()


def writeUnidentifiable():
    os.system('touch ' + UNIDENTIFIABLE_GENE_FILE)
    cleaned_unidentifiable_list = []
    for gene in UNIDENTIFIABLE_LIST:
        if gene not in cleaned_unidentifiable_list:
            cleaned_unidentifiable_list.append(gene)
    if len(cleaned_unidentifiable_list) != 0:
        unidentifiable_file = open(UNIDENTIFIABLE_GENE_FILE, "w")
        unidentifiable_file.write("The following genes cannot be found on the online STRING database, and will not be used in this program:\n\n")
        for gene in cleaned_unidentifiable_list:
            unidentifiable_file.write(gene + "\n")
        unidentifiable_file.close()
    else:
        os.system('rm ' + UNIDENTIFIABLE_GENE_FILE)


def writeChangedName():
    os.system('touch ' + CHANGED_NAME_GENE_FILE)
    if not CHANGED_NAME:
        os.system('rm ' + CHANGED_NAME_GENE_FILE)
    else:
        changed_name_file = open(CHANGED_NAME_GENE_FILE, "w")
        changed_name_file.write("The following genes have been renamed, as per the online STRING database:\n\n")
        for key, value in CHANGED_NAME.iteritems():
            changed_name_file.write(key + " => " + value + "\n")
        changed_name_file.close()


def initialize_connections():
    for gene_info in GENE_LIST:
        gene = gene_info[0]
        GROUP[gene] = "C"


def identifyGroupA(gene_list):
    for i in range(0, len(gene_list)):
        gene = gene_list[i][0]
        gene_neighbors = gene_list[i][1]
        
        for j in range(0, len(gene_list)):
            if i == j:
                continue
            
            other_gene = gene_list[j][0]
            
            if other_gene in gene_neighbors.keys():
                GROUP[gene] = "A"


def identifyGroupB(gene_list):#
    for i in range(0, len(gene_list)):
        
        content_list = []
        gene = gene_list[i][0]
        gene_neighbors = gene_list[i][1]
        
        
        if GROUP[gene] == "A":
            continue
        
        for j in range(0, len(gene_list)):
            if i == j:
                continue

            other_gene = gene_list[j][0]
            other_gene_neighbors = gene_list[j][1]

            for inter_gene in gene_neighbors.keys():
                if inter_gene in other_gene_neighbors.keys():
                    if gene_neighbors[inter_gene] > other_gene_neighbors[inter_gene]:
                        content_list.append([other_gene_neighbors[inter_gene], inter_gene, other_gene])
                    else:
                        content_list.append([gene_neighbors[inter_gene], inter_gene, other_gene]) #confidence level,  d gene, and A or B gene
                                             
        best_match = max(content_list)
        #print(best_match)
        
        if GROUP[gene] == "C":
            GROUP[gene] = "B"
            GROUP[best_match[1]] = "D" #intermediate
            B_D_PAIR[gene] = best_match[1]
            
        
                 


def parseInput():
    os.system('clear')
    arg = ""
    content = []
    input_genes = []
    input_list = []
    if (len(sys.argv) == 1):
        print("Please try running program again, this time adding an argument.")
        sys.exit(0)
    else:
        arg = sys.argv[1]
    if (arg[-4:] == '.txt'): #checking the file extensions
        with open(arg) as arg_input:
            content = arg_input.readlines()
    else:
        print("Please try running program again, this time passing in an argument of type '.txt'")
        sys.exit(0)

    for gene in content:
        input_list.append(gene.replace(" ", "").replace("\n", ""))

    for gene in input_list:
        if gene not in input_genes:
            input_genes.append(gene)

    current_gene_list = GENE_LIST

    for gene in input_genes:
        already_present = False
        for iter in range(0, len(current_gene_list)):
            existing_gene = current_gene_list[iter][0]
            if existing_gene == gene:
                already_present = True
                break

        if already_present == False:
            
            if gene in CHANGED_NAME:
                break
            if gene in UNIDENTIFIABLE_LIST:
                break
            
            gene_info = []
            gene_neighbors = find_neighbor(gene)

            if gene_neighbors == -1:
                UNIDENTIFIABLE_LIST.append(gene)
            else:
                if isinstance(gene_neighbors, basestring):
                    correct_gene = gene_neighbors
                    CHANGED_NAME[gene] = correct_gene
                    gene = correct_gene
                    gene_neighbors = find_neighbor(gene)

                gene_info.append(gene)
                if "" in gene_neighbors:
                    time.sleep(1)
                    gene_info.append(find_neighbor(gene))
                else:
                    gene_info.append(gene_neighbors)
                GENE_LIST.append(gene_info)
        GENE_LIST.sort()
        writeToDatabase()

    initialize_connections()
    identifyGroupA(GENE_LIST)
    identifyGroupB(GENE_LIST)



def getListForGroup(group_id):
    cluster = []
    for gene in GROUP:
        if GROUP[gene] == group_id:
            cluster.append(gene)
    return cluster



def find_neighbor(input_gene):
    gene_connectors = {}
    driver = webdriver.Chrome()
    driver.get("http://string-db.org/")
    driver.find_element_by_id("search").click()
    driver.find_element_by_id("primary_input:single_identifier").send_keys(input_gene)
    driver.find_element_by_id("species_text_single_identifier").send_keys("Homo sapiens")
    driver.find_element_by_xpath("//*[@id='input_form_single_identifier']/div[4]/a").click()
    if "Sorry, STRING did not find a protein" in driver.page_source:
        return -1
    if "Please select one from the list below" in driver.page_source:
        driver.find_element_by_xpath("//*[@id='proceed_form']/div[1]/div/div[2]/a[2]").click()
    driver.find_element_by_id("bottom_page_selector_settings").click()
    driver.find_element_by_xpath("//*[@id='bottom_page_selector_legend']").click()
    page_data = driver.page_source
    split1 = page_data.split("<td class=\"td_name middle_row first_row last_row\" onclick=")
    split2 = split1[1].split("</td>")
    split3 = split2[0].split("\">")
    correct_gene_name = split3[1]
    if input_gene != correct_gene_name:
        return str(correct_gene_name)
    driver.find_element_by_xpath("//*[@id='bottom_page_selector_table']").click()
    driver.find_element_by_id("bottom_page_selector_settings").click()
    driver.find_element_by_xpath("//*[@id='standard_parameters']/div/div[1]/div[3]/div[2]/div[2]/div[1]/label").click()
    driver.find_element_by_xpath("//select[@name='limit']/option[text()='custom value']").click()
    driver.find_element_by_id("custom_limit_input").clear()
    driver.find_element_by_id("custom_limit_input").send_keys("500")
    time.sleep(5)
    driver.find_element_by_xpath("//*[@id='standard_parameters']/div/div[1]/div[5]/a").click()
    time.sleep(10)
    driver.find_element_by_id("bottom_page_selector_table").click()
    driver.find_element_by_xpath("//*[@id='bottom_page_selector_legend']").click()
    connectors = driver.find_elements_by_class_name("linked_item_row")
    for connector in connectors:
        neighbor = str(connector.text.split(' ')[0].split('\n')[0])
        confidence_value = str(connector.text.split(' ')[-1].split('\n')[-1])
        gene_connectors[neighbor] = float(confidence_value)
    return gene_connectors



def download_svg(gene_list):

    if len(gene_list) < 2:
        return -1
    
    SVG_STRING = ""
    for gene in gene_list:
        SVG_STRING = SVG_STRING + gene + "\n"
    
    driver = webdriver.Chrome()
    driver.get("http://string-db.org/")
    driver.find_element_by_id("search").click()
    driver.find_element_by_id("multiple_identifiers").click()
    driver.find_element_by_id("primary_input:multiple_identifiers").send_keys(SVG_STRING)
    driver.find_element_by_id("species_text_multiple_identifiers").send_keys("Homo sapiens")
    driver.find_element_by_xpath("//*[@id='input_form_multiple_identifiers']/div[5]/a").click()
    time.sleep(5)
    if "The following proteins in" in driver.page_source and "appear to match your input" in driver.page_source:
        driver.find_element_by_xpath("//*[@id='proceed_form']/div[1]/div/div[2]/a[2]").click()
    time.sleep(20)
    driver.find_element_by_id("bottom_page_selector_table").click()
    time.sleep(5)
    driver.find_element_by_id("bottom_page_selector_settings").click()
    time.sleep(15)
    driver.find_element_by_id("confidence").send_keys(" ")
    time.sleep(10)
    driver.find_element_by_id("block_structures").send_keys(" ")
    time.sleep(10)
    driver.find_element_by_xpath("//*[@id='standard_parameters']/div/div[1]/div[5]/a").click()
    time.sleep(15)
    driver.find_element_by_xpath("//*[@id='bottom_page_selector_legend']").click()
    time.sleep(10)
    driver.find_element_by_id("bottom_page_selector_table").click()
    time.sleep(25)
    driver.find_element_by_xpath("//*[@id='bottom_page_selector_table_container']/div/div[2]/div/div[3]/div[2]/a").click()
    time.sleep(10)

    terminal_output = subprocess.Popen(['pwd'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = terminal_output.communicate()
    pwd = stdout[:-1]
    downloads_dir = expanduser("~") + '/Downloads/*'
    downloaded_files = glob.glob(expanduser("~") + '/Downloads/*')
    recent_file = max(downloaded_files, key=os.path.getctime)
    move_command = 'mv "' + recent_file + '" "' + pwd + '/svg_files/_base.svg"'
    os.system(move_command)




def getGene(str):
    lst1 = str.split('>')
    lst2 = lst1[1].split('<')
    return lst2[0]



def writeToFile(content, file_name):
    os.system('touch ' + file_name)
    os.system('rm ' + file_name)
    os.system('touch ' + file_name)
    file = open(file_name, "w")
    for counter in range(0, len(content)):
        file.write(str(content[counter]))
    file.close()


"""
    New Idea for Tripod of A's:
    "Hardcode" positions for 3 main genes (ABCA4, RPE65, RHO)
    Split area into 3 zones and use the random generating in each zone
    Venn Diagram into 7 parts (A, B, C, AB, BC, AC, ABC)
        3 extra loser zones
        3 extra zones for the main ones (increase radius maybe, change color maybe)
"""
def classify(group1, group2, group3, group4):    
    GROUP1 = group1[:] #write_only
    GROUP2 = group2[:]
    GROUP3 = group3[:]
    GROUP4 = group4[:]
    
    
    
    a_list = getListForGroup("A")
    
    
    for gene in group1:
        if gene in a_list:
            a_list.remove(gene)
    
    for gene in group2:
        if gene in a_list:
            a_list.remove(gene)
            
    for gene in group3:
        if gene in a_list:
            a_list.remove(gene)
            
    for gene in group4:
        if gene in a_list:
            a_list.remove(gene)
            
    next_input = a_list
    
    while next_input != []: #while there are still loners that are not grouped
        next_input = classify_once(next_input, group1, group2, group3, group4, GROUP1, GROUP2, GROUP3, GROUP4)
        group1 = GROUP1[:]
        group2 = GROUP2[:]
        group3 = GROUP3[:]
        group4 = GROUP4[:]
    l = []
    l.append(GROUP1)
    l.append(GROUP2)
    l.append(GROUP3)
    l.append(GROUP4) 
    return l
    
    

def classify_once(INPUT, group1_r, group2_r, group3_r ,group4_r ,GROUP1, GROUP2, GROUP3, GROUP4): 
    #group1-4 read only, GROUP 1-4 write only
    LONER = []
    '''
    print(GENE_LIST[0][0])
    l = GENE_LIST[0][1].keys()
    l.sort()
    print(l)
    '''
    "ACLY"
    
    
    for a_gene in INPUT: #circle_group #GENE_LIST: a list of lists, each innerr list has two items: the main gene name and a dictionary of name to confidence level
        for i in range(0, len(GENE_LIST)):
            if str(a_gene) == str(GENE_LIST[i][0]):
                count = [0 for j in range(4)] #list of counts of connections in g1,g2,g3,g4
                confidence_level = [0 for k in range(4)]
                #l = GENE_LIST[i][1].keys()
                #l.sort()
                for gene, confidence in GENE_LIST[i][1].iteritems():
                    #print(gene)
                    if gene in group1_r:
                        count[0] += 1
                        confidence_level[0] += confidence
                    elif gene in group2_r:
                        count[1] += 1
                        confidence_level[1] += confidence
                    elif gene in group3_r:
                        count[2] += 1
                        confidence_level[2] += confidence
                    elif gene in group4_r:
                        count[3] += 1
                        confidence_level[3] += confidence
                      
                
                #print("a_gene is")
                #print(a_gene)
            
                    
                #print(count)
                max_count = max(count)
                max_index = [a for a, b in enumerate(count) if b == max_count]
                #print("number of max items is")
                #print(len(max_index))
            
                
                if count == [ 0 for num in range(4) ]:# no connections at all
                    LONER.append(a_gene)
                    
                elif len(max_index) == 1:
                    if max_index[0] == 0:
                        GROUP1.append(a_gene)
                    elif max_index[0] == 1:
                        GROUP2.append(a_gene)
                    elif max_index[0] == 2:
                        GROUP3.append(a_gene)
                    elif max_index[0] == 3:
                        GROUP4.append(a_gene)    
                        
                else: #use confidence level to compare
                    #print("max_index")
                    #print(max_index)
                    
                 
                    finalists = [confidence_level[n] for n in  max_index ]
                    
                    #print("conf level")
                    #print(finalists)
                    
                    max_conf = max(finalists)
                    index =  [a for a, b in enumerate(finalists) if b == max_conf]#index with the maximumn conf value
                    #print("max conf index")
                    #print(index)
                    #print("\n")
                    group_num = max_index[index[0]] #if there's a confidence level tie, then just do random. We just choose the first index we find then.
                    
                    if group_num == 0:
                        GROUP1.append(a_gene)
                    elif group_num == 1:
                        GROUP2.append(a_gene)
                    elif group_num == 2:
                        GROUP3.append(a_gene)
                    elif group_num == 3:
                        GROUP4.append(a_gene)  
    '''
    print(len(INPUT))
    
    print("GROUP1: " + str(len(GROUP1)) )
    print("GROUP2: " + str(len(GROUP2)) )
    print("GROUP3: " + str(len(GROUP3)) )
    print("GROUP4: " + str(len(GROUP4)) )
    print("LONER: " + str(len(LONER)) )
    #print(LONER)
    '''
    return LONER

    
    '''
    print(GROUP1)
    print(GROUP2)
    print(GROUP3)
    print(GROUP4)
    print(LONER)
    '''    
                        


def modify_base_svg(groups):   #450 lines long lmao  
    grey = "(217,217,217)"
    yellow = "(255,255,0)"
    red = "(255,0,0)"
    green = "(0,153,0)"
    blue = "(52,152,219)"

    
    with open("svg_files/_base.svg") as base:
        content = base.readlines()

    content[0] = "<svg class=\"notselectable\" height=\"3500\" id=\"svg_network_image\" width=\"3500\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">"

    height = 3500
    width = 3500 #

    old_pos_dict = {}
    
    new_pos_dict = {} #key: string name of gene, value: [str(b_x), str(b_y)]
    
    
    GROUP1 = groups[0]
    GROUP2 = groups[1]
    GROUP3 = groups[2]
    GROUP4 = groups[3]
    
    
    d_list = getListForGroup("D")
    print("d_list:")
    print(d_list)
    a_list = getListForGroup("A")
    
    
    D_A_1 = {}
    D_A_2 = {}
    D_A_3 = {}
    D_A_4 = {}
    for d_gene in d_list:
         D_A_1[d_gene] = [0, "", 0.0]
         D_A_2[d_gene] = [0, "", 0.0]
         D_A_3[d_gene] = [0, "", 0.0]
         D_A_4[d_gene] = [0, "", 0.0]
    
    for i in range(len(GENE_LIST)):
       a_gene = GENE_LIST[i][0] #not necssarily a gene tho, just an input gene
       
       if a_gene in GROUP1:
           genes = GENE_LIST[i][1].keys()
           for d_gene in d_list:
               if d_gene in genes:
                   D_A_1[d_gene][0] = D_A_1[d_gene][0] + 1
                   
                   if GENE_LIST[i][1][d_gene] >  D_A_1[d_gene][2]:
                       D_A_1[d_gene][2] = GENE_LIST[i][1][d_gene] #replace with the bigger confidence level
                       D_A_1[d_gene][1] = a_gene
                   
       if a_gene in GROUP2:
           genes = GENE_LIST[i][1].keys()
           for d_gene in d_list:
               if d_gene in genes:
                   D_A_2[d_gene][0] = D_A_2[d_gene][0] + 1
                   
                   if GENE_LIST[i][1][d_gene] >  D_A_2[d_gene][2]:
                       D_A_2[d_gene][2] = GENE_LIST[i][1][d_gene] #replace with the bigger confidence level
                       D_A_2[d_gene][1] = a_gene
                   
       if a_gene in GROUP3:
           genes = GENE_LIST[i][1].keys()
           for d_gene in d_list:
               if d_gene in genes:
                   D_A_3[d_gene][0] = D_A_3[d_gene][0] + 1
                   
                   if GENE_LIST[i][1][d_gene] >  D_A_3[d_gene][2]:
                       D_A_3[d_gene][2] = GENE_LIST[i][1][d_gene] #replace with the bigger confidence level
                       D_A_3[d_gene][1] = a_gene
                   
       if a_gene in GROUP4:
           genes = GENE_LIST[i][1].keys()
           for d_gene in d_list:
               if d_gene in genes:
                   D_A_4[d_gene][0] = D_A_4[d_gene][0] + 1
                   
                   if GENE_LIST[i][1][d_gene] >  D_A_4[d_gene][2]:
                       D_A_4[d_gene][2] = GENE_LIST[i][1][d_gene] #replace with the bigger confidence level
                       D_A_4[d_gene][1] = a_gene
                          
    #print(D_A_1)
    #print(D_A_2)
    #print(D_A_3)
    #print(D_A_4)
    
    A_D_final = {} #the dictionary that maps which A gene should the D gene be placed to on the graph
    #we first determine what circle the D gene should belong to, then we compare what A gene in the circle
    #does the d gene have the highest confidence level with
    for a_gene in a_list:
        A_D_final[a_gene] = []
    
    dict_list = []
    dict_list.append(D_A_1)
    dict_list.append(D_A_2)
    dict_list.append(D_A_3)
    dict_list.append(D_A_4)
    for d_gene in d_list:
        counts = [dic[d_gene][0] for dic in dict_list] # list of counts for group 1 thru 4
        max_count = max(counts)
        max_index = [a for a, b in enumerate(counts) if b == max_count]
        
        if len(max_index) == 1: #only one maximum value among 4 groups
            a_gene = dict_list[max_index [0] ][d_gene] [1]
            # a to a list of d_genes
            A_D_final[a_gene].append(d_gene)
            
        else:
            dict_list_final = [dict_list[k] for k in max_index]
            confidence_levels = [dic[d_gene][2] for dic in dict_list_final ]# the confidence levels of the finalists
            max_conf = max(confidence_levels)
            index =  [a for a, b in enumerate(confidence_levels) if b == max_conf]
            group_num = max_index[index[0]] #groupnum = 0 1 2 or 3
            
            a_gene = dict_list[group_num][d_gene][1]#dict_list[group_num][d_gene] is something like [1, 'FDFT1', 0.4]
            A_D_final[a_gene].append(d_gene)
    #print(len(A_D_final))
    #print(A_D_final.values())
    '''
    for key,val in A_D_final.items():
        if val != []:
            print(key)
            print(val)
    '''
    
    D_B_PAIR = {v: k for k, v in B_D_PAIR.iteritems()}
    
    #HERE WE CHANG THE LOCATION OF THE A GENES TO BE IN CICRLES. CHANGE THE LOCATION OF THE D GENES TOO

    radius_2 = len(GROUP2) * 14
    center_2 = radius_2 + 200
    
    '''
    for k in range(len(GROUP2)):
        if GROUP2[k] == "EMC1":
            print(k)
    '''
    
    
    GROUP2.remove("EMC1")
    GROUP2.remove("ALB")
    
    GROUP2.insert(51,"ALB")
    GROUP2.append("EMC1")
    
    for i in range(len(GROUP2)): #78
        x = int(round(center_2 + radius_2 * math.cos(6.28/len(GROUP2)*i) ))
        y = int(round(center_2 + radius_2 * math.sin(6.28/len(GROUP2)*i) ))
        new_pos_dict[GROUP2[i]] = [ str(x), str(y) ]
        if GROUP2[i] in A_D_final.keys():
            d_gene_per_a = len(A_D_final[GROUP2[i]])
            if d_gene_per_a == 1: #there are only one d_gene matched to the a_gene
                d_gene = A_D_final[GROUP2[i]][0]
                radius_d = radius_2 * 1.07
                d_x = int(round(center_2 + radius_d * math.cos(6.28/len(GROUP2)*i) ))
                d_y = int(round(center_2 + radius_d * math.sin(6.28/len(GROUP2)*i) ))
                new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                #print(d_gene + " G2 modified!")
                
                b_gene = D_B_PAIR[d_gene]
                radius_d = radius_d * 1.07
                b_x = int(round(center_2 + radius_d * math.cos(6.28/len(GROUP2)*i) ))
                b_y = int(round(center_2 + radius_d * math.sin(6.28/len(GROUP2)*i) ))
                new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
                
                  
            elif d_gene_per_a > 1:
                angle_1 = i - 1.001/d_gene_per_a
                for k in range(d_gene_per_a):
                    angle = angle_1 + k * 1.001/(d_gene_per_a -1)
                    d_gene = A_D_final[GROUP2[i]][k]
                    radius_d = radius_2 * 1.11
                    d_x = center_2 + radius_d * math.cos(6.28/len(GROUP2)*angle) #QUES: SEE IF U LIKE
                    d_y = center_2 + radius_d * math.sin(6.28/len(GROUP2)*angle) 
                    new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                    #print(d_gene +" G2 modified!")
                    
                    b_gene = D_B_PAIR[d_gene]
                    radius_d = radius_d * 1.07
                    b_x = int(round(center_2 + radius_d * math.cos(6.28/len(GROUP2)*angle) ))
                    b_y = int(round(center_2 + radius_d * math.sin(6.28/len(GROUP2)*angle) ))
                    new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]

                    
     
        



    radius_1 = len(GROUP1) * 14
    center_1 = 2 * radius_2 + 400
    for i in range(len(GROUP1)): #7
        x = int(round(center_1 + 500  + radius_1 * math.cos(6.28/len(GROUP1)*i) ))
        y = int(round(center_1/2  + radius_1 * math.sin(6.28/len(GROUP1)*i) ))
        new_pos_dict[GROUP1[i]] = [ str(x), str(y) ]
        if GROUP1[i] in A_D_final.keys():
            d_gene_per_a = len(A_D_final[GROUP1[i]])
            if d_gene_per_a == 1: #there are only one d_gene matched to the a_gene
                d_gene = A_D_final[GROUP1[i]][0]
                radius_d = radius_1 * 1.2
                d_x = int(round(center_1 + 500  + radius_d * math.cos(6.28/len(GROUP1)*i) ))
                d_y = int(round(center_1/2 + radius_d * math.sin(6.28/len(GROUP1)*i) ))
                new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                #print(d_gene +" G1 modified!")
                
                b_gene = D_B_PAIR[d_gene]
                radius_d = radius_d * 1.07
                b_x = int(round(center_1 + 500  + radius_d * math.cos(6.28/len(GROUP1)*i) ))
                b_y = int(round(center_1/2 + radius_d * math.sin(6.28/len(GROUP1)*i) ))
                new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
            
            elif d_gene_per_a > 1:
                angle_1 = i - 1.001/d_gene_per_a
                for k in range(d_gene_per_a):
                    angle = angle_1 + k * 1.001/(d_gene_per_a -1)
                    d_gene = A_D_final[GROUP1[i]][k]
                    radius_d = radius_1 * 1.11
                    
                    d_x = int(round(center_1 + 500  + radius_d * math.cos(6.28/len(GROUP1)*angle) ))
                    d_y = int(round(center_1/2 + radius_d * math.sin(6.28/len(GROUP1)*angle) ))
                    new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                    #print(d_gene +" G2 modified!")
                    
                    b_gene = D_B_PAIR[d_gene]
                    radius_d = radius_d * 1.07
                    b_x = int(round(center_1 + 500  + radius_d * math.cos(6.28/len(GROUP1)*angle) ))
                    b_y = int(round(center_1/2 + radius_d * math.sin(6.28/len(GROUP1)*angle) ))
                    new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
                
        
        
        
    
            
    radius_4 = len(GROUP4) * 14
    center_4 = 2 * radius_2 + 200
    
    for i in range(len(GROUP4)): #49
        x = int(round(center_4 + 300 + 50 + radius_4 * math.cos(6.28/len(GROUP4)*i) ))
        y = int(round(center_4 + 200 + radius_4 * math.sin(6.28/len(GROUP4)*i) ))
        new_pos_dict[GROUP4[i]] = [ str(x), str(y) ]
        if GROUP4[i] in A_D_final.keys():
            d_gene_per_a = len(A_D_final[GROUP4[i]])
            if d_gene_per_a == 1: #there are only one d_gene matched to the a_gene
                d_gene = A_D_final[GROUP4[i]][0]
                radius_d = radius_4 * 1.1
                d_x = int(round(center_4 + 300 + 50 + radius_d * math.cos(6.28/len(GROUP4)*i) ))
                d_y = int(round(center_4 +  200 + radius_d * math.sin(6.28/len(GROUP4)*i) ))
                new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                #print(d_gene +" G4 modified!") #QUES: not changing this node for some reason
                
                b_gene = D_B_PAIR[d_gene]
                radius_d = radius_d * 1.07
                b_x = int(round(center_4 + 300 + 50 + radius_d * math.cos(6.28/len(GROUP4)*i) ))
                b_y = int(round(center_4 +  200 + radius_d * math.sin(6.28/len(GROUP4)*i) ))
                new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
                
            elif d_gene_per_a > 1:
                angle_1 = i - 1.001/d_gene_per_a
                for k in range(d_gene_per_a):
                    angle = angle_1 + k * 1.001/(d_gene_per_a -1)
                    d_gene = A_D_final[GROUP4[i]][k]
                    radius_d = radius_4 * 1.11
                    
                    d_x = int(round(center_4 + 300 + 50 + radius_d * math.cos(6.28/len(GROUP4)*angle) ))
                    d_y = int(round(center_4 +  200 + radius_d * math.sin(6.28/len(GROUP4)*angle) ))
                    new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                    
                    b_gene = D_B_PAIR[d_gene]
                    radius_d = radius_d * 1.07
                    b_x = int(round(center_4 + 300 + 50 + radius_d * math.cos(6.28/len(GROUP4)*angle) ))
                    b_y = int(round(center_4 +  200 + radius_d * math.sin(6.28/len(GROUP4)*angle) ))
                    new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
    
            
        
        
        
    radius_3 = len(GROUP3) * 14
    center_3 = center_4 
    
    for i in range(len(GROUP3)): #15
        x = int(round(center_3 - 1200 + radius_3 * math.cos(6.28/len(GROUP3)*i) ))
        y = int(round(center_3 +500 + radius_3 * math.sin(6.28/len(GROUP3)*i) ))
        new_pos_dict[GROUP3[i]] = [ str(x), str(y) ]
        
        if GROUP3[i] in A_D_final.keys():
            d_gene_per_a = len(A_D_final[GROUP3[i]])
            if d_gene_per_a == 1: #there are only one d_gene matched to the a_gene
                d_gene = A_D_final[GROUP3[i]][0]
                radius_d = radius_3 * 1.2
                d_x = int(round(center_3 - 1200 + radius_d * math.cos(6.28/len(GROUP3)*i) ))
                d_y = int(round(center_3 +500  + radius_d * math.sin(6.28/len(GROUP3)*i) ))
                new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                #print(d_gene +" G3 modified!")
                
                b_gene = D_B_PAIR[d_gene]
                radius_d = radius_d * 1.07
                b_x = int(round(center_3 - 1200 + radius_d * math.cos(6.28/len(GROUP3)*i) ))
                b_y = int(round(center_3 +500  + radius_d * math.sin(6.28/len(GROUP3)*i) ))
                new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
                
            elif d_gene_per_a > 1:
                angle_1 = i - 1.001/d_gene_per_a
                for k in range(d_gene_per_a):
                    angle = angle_1 + k * 1.001/(d_gene_per_a -1)
                    d_gene = A_D_final[GROUP3[i]][k]
                    radius_d = radius_3 * 1.11
                    d_x = int(round(center_3 - 1200 + radius_d * math.cos(6.28/len(GROUP3)*angle) ))
                    d_y = int(round(center_3 +500  + radius_d * math.sin(6.28/len(GROUP3)*angle) ))
                    new_pos_dict[d_gene] = [ str(d_x), str(d_y) ]
                    
                    b_gene = D_B_PAIR[d_gene]
                    radius_d = radius_d * 1.07
                    b_x = int(round(center_3 - 1200 + radius_d * math.cos(6.28/len(GROUP3)*angle) ))
                    b_y = int(round(center_3 +500  + radius_d * math.sin(6.28/len(GROUP3)*angle) ))
                    new_pos_dict[b_gene] = [ str(b_x), str(b_y) ]
    
    #change locations of the nodes:
    
    length = len(content)
    for i in range(length): #change color, delete ellipses, and initialize old_pos_dict
        gene_name = ""
        
        if "ellipse cx=" in content[i]:
            content[i] = ""
        
        if "circle class" in content[i]:
            
            gene_name = getGene(content[i+3])
            rgb_val = content[i].split("rgb")[1].split('"')[0]
            position_data = content[i].split("cx=")[1].split(" display")[0].replace("cy=", "").replace("\"", "")
            old_pos_dict[position_data] = gene_name #initialize old_pos_dict
            
            #if gene_name == "ABCA4" or gene_name == "RPE65" or gene_name == "RHO":
             #   content[i] = content[i].replace(rgb_val, blue)
                
            if GROUP[gene_name] == "A":
                content[i] = content[i].replace(rgb_val, blue)
            elif GROUP[gene_name] == "B":
                content[i] = content[i].replace(rgb_val, yellow)
            elif GROUP[gene_name] == "C":
                content[i] = content[i].replace(rgb_val, red)
            elif GROUP[gene_name] == "D":
                content[i] = content[i].replace(rgb_val, green)

    a_list = getListForGroup("A")
    b_list = getListForGroup("B")
    c_list = getListForGroup("C")
    d_list = getListForGroup("D")
    


    base_b_y = int(height / 6)
    lowest_d_y = 0
   
     

    #actually changing the content in the file 
    for i in range(length):

            
        if "line class=\"nw_edge\"" in content[i] and ".0\" stroke=" in content[i]:
            content[i] = ""
        
        
        if "line class=\"nw_edge\"" in content[i] and ((".1\" stroke=" in content[i]) or (".2\" stroke=" in content[i])): #updating the edge pos
            old_width = float(content[i].split("stroke-width=\"")[1].split("\"")[0])
            old_opacity = float(content[i].split("stroke-opacity=\"")[1].split("\"")[0])
            new_width = str(0.50 * old_width)
            new_opacity = str(0.50 * old_opacity)

            
            
            old_x1 = content[i].split("x1=\"")[1].split("\"")[0]
            old_y1 = content[i].split("y1=\"")[1].split("\"")[0]
            old_x2 = content[i].split("x2=\"")[1].split("\"")[0]
            old_y2 = content[i].split("y2=\"")[1].split("\"")[0]
            
            mod_old_x1 = str(float(old_x1) - 0.5)
            mod_old_x2 = str(float(old_x2) - 0.5)
            mod_old_y1 = str(float(old_y1) - 0.5)
            mod_old_y2 = str(float(old_y2) - 0.5)
            
            if ".0" in mod_old_x1:
                mod_old_x1 = mod_old_x1[:-2]
            if ".0" in mod_old_x2:
                mod_old_x2 = mod_old_x2[:-2]
            if ".0" in mod_old_y1:
                mod_old_y1 = mod_old_y1[:-2]
            if ".0" in mod_old_y2:
                mod_old_y2 = mod_old_y2[:-2]
            
            gene1_name = old_pos_dict[str(mod_old_x1) + " " + str(mod_old_y1)]
            gene2_name = old_pos_dict[str(mod_old_x2) + " " + str(mod_old_y2)]
           
    
            if gene1_name in new_pos_dict and gene2_name in new_pos_dict: 
                new_pos1 = new_pos_dict[gene1_name]
                new_pos2 = new_pos_dict[gene2_name]
                updated_new_pos1 = [str(float(new_pos1[0]) + 0.5), str(float(new_pos1[1]) + 0.5)]
                updated_new_pos2 = [str(float(new_pos2[0]) + 0.5), str(float(new_pos2[1]) + 0.5)]
                first_half = content[i].split("stroke-opacity=\"")[0]
                #second_half = content[i].split("/>")[1]
                content[i] = first_half + "stroke-opacity=\"" + new_opacity + "\" stroke-width=\"" + new_width + "\" style=\"\""  +" x1=\"" + updated_new_pos1[0] + "\" y1=\"" + updated_new_pos1[1] + "\" x2=\"" + updated_new_pos2[0] + "\" y2=\"" + updated_new_pos2[1] + "\" />" + "\n"
                
        
        if "<circle cx" in content[i]: #update the node pos
            old_x = content[i].split("cx=\"")[1].split("\"")[0]
            old_y = content[i].split("cy=\"")[1].split("\"")[0]
            gene_name = old_pos_dict[str(old_x) + " " + str(old_y)]
            if gene_name in new_pos_dict:
                new_pos = new_pos_dict[gene_name]
                first_half = content[i].split(" cx=")[0]
                second_half = content[i].split("fill=")[1]
                content[i] = first_half + " cx=\"" + new_pos[0] + "\" cy=\"" + new_pos[1] + "\" fill=" + second_half
        
        if "<circle class" in content[i]: #update the node pos too, need to change multiple places
            old_x = content[i].split("cx=\"")[1].split("\"")[0]
            old_y = content[i].split("cy=\"")[1].split("\"")[0]
            gene_name = old_pos_dict[str(old_x) + " " + str(old_y)]
            if gene_name in new_pos_dict:
                new_pos = new_pos_dict[gene_name]
                first_half = content[i].split(" cx=")[0]
                second_half = content[i].split("display=")[1]
                content[i] = first_half + " cx=\"" + new_pos[0] + "\" cy=\"" + new_pos[1] + "\" display=" + second_half
                    
        if "<text " in content[i]: #update the text pos
            old_text_x = content[i].split("x=\"")[1].split("\"")[0]
            old_text_y = content[i].split("y=\"")[1].split("\"")[0]
            old_x = str(float(old_text_x) - 18)
            old_y = str(float(old_text_y) + 18)
            
            if ".0" in old_x:
                old_x = old_x[:-2]
            if ".0" in old_y:
                old_y = old_y[:-2]
            
            gene_name = old_pos_dict[str(old_x) + " " + str(old_y)]
            if gene_name in new_pos_dict:
                new_pos = new_pos_dict[gene_name]
                new_text_pos = [str(float(new_pos[0]) + 18), str(float(new_pos[1]) - 18)]
                
                first_half = content[i].split("x=")[0]
                second_half = "x=\"" + new_text_pos[0] + "\" y=\"" + new_text_pos[1] + "\">" + gene_name + "</text>\n"
                
                content[i] = first_half + second_half
    
    writeToFile(content, "svg_files/_modified_base.svg")


    #the function to distribute the points in a rectangle

def distribute_points(new_pos_dict, a_list, x_left_bound, x_right_bound, y_low_bound, y_up_bound, iso_zone, x_center, y_center):
    new_x_list = []
    new_y_list = []
    key_num = random.SystemRandom()

    for i in range(len(a_list)): 
        a_x_val = -1
        a_y_val = -1
        
        while True: #the statement in the while loop is just for one pick
            count = 0 #number of times we've checked the items ti make sure not overlapping with chosen points

            A_new_x = key_num.randint( x_left_bound, x_right_bound )
            A_new_y = key_num.randint( y_low_bound, y_up_bound )
            
            if iso_zone: 
                dist2 = math.sqrt( abs(x_center -  A_new_x) ** 2 + abs(y_center -  A_new_y) **2  )
                if dist2 < 42:
                    continue

            for j in range(len(new_y_list)):
                dist = math.sqrt(abs(new_x_list[j] -  A_new_x) * abs(new_x_list[j] -  A_new_x) + abs(new_y_list[j] -  A_new_y) * abs(new_y_list[j] -  A_new_y))
                if (dist < 57):
                    break #failed, generate a new number
                count = count + 1
                
            if count == len(new_y_list):
                a_x_val = A_new_x
                a_y_val = A_new_y
                break #when count in 
                
            
        new_x_list.append(a_x_val)
        new_y_list.append(a_y_val)
        new_pos_dict[a_list[i]] = [str(a_x_val), str(a_y_val)] 
        

   
def insert_line(x1, y1, x2, y2, content, i):
    first = "\t\t<g class=\"nwlinkwrapper\" id=\"edge.1111111.1111111\">\n"
    second =	"	\t\t<line class=\"nw_edge\" id=\"line.1111111.1111111.1\" stroke=\"#FF4500\" stroke-dasharray=\"none\" stroke-opacity=\"0.362\" stroke-width=\"7\" style=\"\" x1=\"" + str(x1) + "\" y1=\""+ str(y1)+ "\" x2=\"" + str(x2) + "\" y2=\"" + str(y2)+ "\" />\n"
    
    #index = n
    #second_2 =  "n" + "\" stroke=\"#0000FF\" stroke-dasharray=\"none\" stroke-opacity=\"0.362\" stroke-width=\"5\" style=\"\" x1=\"1609.5\" y1=\"1353.5\" x2=\"489.5\" y2=\"2051.5\" />"
    third = "		</g>\n"
    content.insert(i,third)
    content.insert(i,second)
    content.insert(i,first)
    
    
    

def create_svg(b_gene):

    with open("svg_files/_modified_base.svg") as modified_base:
        content = modified_base.readlines()
    
    naughty_b_list = []
    naughty_d_list = []
    b_list = getListForGroup("B")
    for b in b_list:
        if b != b_gene:
            naughty_b_list.append(b)
            naughty_d_list.append(B_D_PAIR[b])

    naughty_b_numbers = []
    naughty_d_numbers = []

    length = len(content)
    for i in range(length):
        if "<text fill=\"white\"" in content[i]:
            gene_line = content[i].split("</text>")[0].split(">")[1]
            
            if gene_line in naughty_b_list or gene_line in naughty_d_list:
                naughty_x = content[i-1].split("cx=\"")[1].split("\"")[0]
                naughty_y = content[i-1].split("cy=\"")[1].split("\"")[0]
                
                naughty_x = str(float(naughty_x) + 0.5)
                naughty_y = str(float(naughty_y) + 0.5)
                
                if gene_line in naughty_b_list:
                    naughty_b_numbers.append(naughty_x + " " + naughty_y)
                if gene_line in naughty_d_list:
                    naughty_d_numbers.append(naughty_x + " " + naughty_y)
                    for j in range(i - 4, i + 3):
                        content[j] = ""
    for i in range(length):
        if "<line class" in content[i]:
            x1 = content[i].split("x1=\"")[1].split("\"")[0]
            y1 = content[i].split("y1=\"")[1].split("\"")[0]
            pos1 = x1 + " " + y1
            x2 = content[i].split("x2=\"")[1].split("\"")[0]
            y2 = content[i].split("y2=\"")[1].split("\"")[0]
            pos2 = x2 + " " + y2
            if pos1 in naughty_b_numbers or pos2 in naughty_b_numbers or pos1 in naughty_d_numbers or pos2 in naughty_d_numbers:
                for j in range(i - 1, i + 2):
                    content[j] = ""

    writeToFile(content, "svg_files/" + b_gene + ".svg")


def count_A_group(): #ABCA4, RPE65, RHO 
    a = []
    b = []
    c = []
    ab = []
    bc = []
    ac = []
    abc = []
    loner = []
    
    A_genes = getListForGroup("A")
    print(len(A_genes))
    for gene in A_genes:
        for l in GENE_LIST:
            if gene == l[0]:
                #print(l[0])
                #print(l[1])

                genes_connected = l[1].keys()
                A =  "ABCA4" in genes_connected 
                B = "RPE65" in genes_connected 
                C = "RHO" in genes_connected 
                if gene != "ABCA4" and gene != "RPE65" and gene != "RHO":
                    if (A and B and C):
                        abc.append(gene)
                    elif (A and B and not C):
                        ab.append(gene)
                    elif (A and C and not B):
                        ac.append(gene)
                    elif (B and C and not A):
                        bc.append(gene)
                    elif (A and not B and not C):
                        a.append(gene)
                    elif (B and not A and not C):
                        b.append(gene)
                    elif (C and not A and not B):
                        c.append(gene)
                    else:
                        loner.append(gene)
    
    print("A:" +  str(len(a)))
    print("B:" + str(len(b)))
    print("C:" +  str(len(c)))
    print("AB:" + str(len(ab)))
    print("BC:" + str(len(bc)))
    print("AC:" + str(len(ac)))
    print("ABC:" + str(len(abc)))
    print("loner:" + str(len(loner)))
    
    print(len(a) + len(b) +len(c) + len(ab) + len(bc) + len(ac) + len(abc) + len(loner) )
    l = []
    l.append(a)
    l.append(b)
    l.append(c)
    l.append(ab)
    l.append(bc)
    l.append(ac)
    l.append(abc)
    
    half = len(loner)/2
    loners_left = loner[:half]
    loners_right = loner[half:]

    l.append(loners_left)
    l.append(loners_right)
    return l 
                    
    #print(GENE_LIST) # a list of lists (that contains the gene name and the dictionary)

def main():   
    os.system('mkdir info_files')
    os.system('mkdir svg_files')
    os.system('touch ' + GENE_DATABASE_FILE)
    os.system('touch ' + UNIDENTIFIABLE_GENE_FILE)
    os.system('touch ' + CHANGED_NAME_GENE_FILE)
    readDatabase()
    readUnidentifiable()
    readChangedName()
    
    
    parseInput()
    groups = classify(group1, group2, group3, group4)

    writeGeneGroups()
    writeUnidentifiable()
    writeChangedName()

    
    '''
    entire_list = []
    entire_list.extend(getListForGroup("A"))
    entire_list.extend(getListForGroup("B"))
    entire_list.extend(getListForGroup("C"))
    entire_list.extend(getListForGroup("D"))
    
        
    for gene in group1:
        if gene not in entire_list :
            entire_list.append(gene)
    
    for gene in group2:
        if gene not in entire_list :
            entire_list.append(gene)
            
    for gene in group3:
        if gene not in entire_list :
            entire_list.append(gene)
            
            
    for gene in group4:
        if gene not in entire_list :
            entire_list.append(gene)
    
    
    download_svg(entire_list)
    
    
    '''
    modify_base_svg(groups)
    
    
    '''
    b_list = getListForGroup("B")
    for b_gene in b_list:
        create_svg(b_gene)
    
    '''
    
if __name__ == "__main__":
    main()
